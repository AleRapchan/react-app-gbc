const Home = (props) => {
  
  return (
    <div>
      <p>Home</p>
    </div>
  ); 
};

export default Home;