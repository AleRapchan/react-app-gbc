const Contact = () => {
  return (
    <div>
      <p>Contact</p>
    </div>
  ); 
};

export default Contact;