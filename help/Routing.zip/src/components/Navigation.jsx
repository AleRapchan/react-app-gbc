
import { Link } from "react-router-dom";


const Navigation = () => (
    <ul>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/Contact">Contact</Link></li>
      <li><Link to="/About">About</Link></li>
      <li><Link to="/Student/James%20Smith">Student: Jim Smith</Link></li>
      <li><Link to="/Student/James%20Smith/50001">Student: Jane Smith, Student No: 50001</Link></li>
      <li><Link to="/Redirect">Redirect</Link></li>
    </ul>
);

export default Navigation