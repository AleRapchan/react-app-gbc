
const Student = ({ match }) => {
  
  const { studentname } = match.params ;
  const { studentno } = match.params ;

  const StudentNo = () => {
    if (studentno){
    return (<div><p>{`The student no is ${studentno}`}</p></div>); 
    }else{
      return(<></>);
    }
  };

  const StudentName = () => {
    return (<div>{`The student name is "${studentname}"!`}</div>); 
  };

  return (
    <div>
      <p>Student</p>
      <div>  
        <StudentName />
        <StudentNo />
      </div>
    </div>
  ); 
};

export default Student;
