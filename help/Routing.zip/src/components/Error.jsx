

const Error = () => {
  return (
    <div>
      <p>Error</p>
    </div>
  ); 
};

export default Error;